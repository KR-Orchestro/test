#!/bin/sh
sudo ./access_server -config ./access_server.cfg 
