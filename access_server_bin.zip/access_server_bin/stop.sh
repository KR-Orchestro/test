#!/bin/sh
sudo killall access_server
